<?php
/**
 * @package         Convert Forms
 * @version         4.4.8 Free
 * 
 * @author          Tassos Marinos <info@tassos.gr>
 * @link            https://www.tassos.gr
 * @copyright       Copyright © 2024 Tassos All Rights Reserved
 * @license         GNU GPLv3 <http://www.gnu.org/licenses/gpl.html> or later
*/

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
?>
<p style="margin-top: 16px;"><?php echo Text::sprintf('COM_CONVERTFORMS_NO_RESULTS_FOUND', Text::_('COM_CONVERTFORMS_SUBMISSIONS')) ?></p>