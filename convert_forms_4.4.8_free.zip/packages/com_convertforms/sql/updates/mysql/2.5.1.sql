ALTER TABLE `#__convertforms_conversions` ADD INDEX `form_id` (`form_id`);
ALTER TABLE `#__convertforms_conversions` ADD INDEX `campaign_id` (`campaign_id`);