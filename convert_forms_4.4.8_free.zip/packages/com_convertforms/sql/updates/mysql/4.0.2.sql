ALTER TABLE `#__convertforms_tasks` CHANGE `created` `created` DATETIME NOT NULL;
ALTER TABLE `#__convertforms_connections` CHANGE `created` `created` DATETIME NOT NULL;
ALTER TABLE `#__convertforms_tasks_history` CHANGE `created` `created` DATETIME NOT NULL;