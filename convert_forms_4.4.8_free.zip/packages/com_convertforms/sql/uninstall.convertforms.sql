DROP TABLE IF EXISTS 
`#__convertforms`,
`#__convertforms_campaigns`,
`#__convertforms_conversions`,
`#__convertforms_tasks`,
`#__convertforms_tasks_history`,
`#__convertforms_connections`;