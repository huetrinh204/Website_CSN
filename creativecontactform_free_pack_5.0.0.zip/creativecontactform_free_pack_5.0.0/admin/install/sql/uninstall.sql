DROP TABLE IF EXISTS `#__contact_templates`;
DROP TABLE IF EXISTS `#__creative_forms`;
DROP TABLE IF EXISTS `#__creative_fields`;
DROP TABLE IF EXISTS `#__creative_field_types`;
DROP TABLE IF EXISTS `#__creative_form_options`;
DROP TABLE IF EXISTS `#__creative_submissions`;